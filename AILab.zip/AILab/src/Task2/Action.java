package Task2; 

public abstract class Action {
	public abstract boolean isNoOp();
}