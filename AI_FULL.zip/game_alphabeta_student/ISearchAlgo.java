package game_alphabeta_student;

public interface ISearchAlgo {
	public void execute(Node node);


}
