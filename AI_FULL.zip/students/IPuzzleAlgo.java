package students;

public interface IPuzzleAlgo {
	public Node execute(Puzzle model);
}
